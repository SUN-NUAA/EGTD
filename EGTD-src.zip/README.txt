1. Before runing the program, the ucr datasets should be downloaded, available at: www.cs.ucr.edu/~eamonn/time_series_data/
2. Specify the location of the data sets in the file system, in line 15 in "main.py".
3. Several modules may have to be installed, such as pandas, numpy, quad.
4. Execute "python main.py" in command line.
5. The output of the program is just the overall MAE and RMSE. If more detailed results are needed, just add "print" functions in the file "main.py" as you like.