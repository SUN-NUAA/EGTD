# -*- coding: utf-8 -*-
"""
Created on Wed Nov 15 16:47:01 2023

@author: foolinsky
"""

import os
import pandas as pd
import numpy as np
import L
import entropy
import egtd

setPath='D:\\Data\\UCR\\orig\\'
setNames = os.listdir(setPath)

iSet=0      #index of dataset in ucr archive
m=4         #number of uncertain sources
nmin=1000   #if number of samples in a dataset less than nmin,
            #each sample will be calculated multiple times

df1=pd.read_csv(setPath+'\\'+setNames[iSet]+'\\'+setNames[iSet]+'_TEST',header=None)
df2=pd.read_csv(setPath+'\\'+setNames[iSet]+'\\'+setNames[iSet]+'_TRAIN',header=None)
df=pd.concat((df1,df2))
samp=df.values[:,1:]
del df,df1,df2
lp=L.lprime(samp.shape[1])
samp=samp[:,0:lp]
samp=np.expand_dims(samp,axis=1)
samp=np.repeat(samp,m+1,axis=1)
samp=np.repeat(samp,(nmin+samp.shape[0]-1)//samp.shape[0],axis=0)
std=np.abs(np.random.randn(samp.shape[0],m+1))
std[:,0]=0
err=std
err=np.expand_dims(err,axis=2)
err=np.repeat(err,samp.shape[2],axis=2)
err*=np.random.randn(samp.shape[0],samp.shape[1],samp.shape[2])
samp+=err

for j in range(samp.shape[0]):
    # print(std[j])
    # print(entropy.entropy2(samp[j]))
    w=egtd.opt(samp[j,1:,:])
    truth=samp[j,0,:]
    ftruth=np.dot(np.expand_dims(w,axis=0),samp[j,1:,:]).reshape((lp,))
    rmse=np.sqrt(np.mean((ftruth-truth)**2))
    mae=np.mean(np.abs(ftruth-truth))
    print(rmse, mae)
    break

